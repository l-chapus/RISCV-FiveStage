package FiveStage
import chisel3._
import chisel3.util.{ BitPat, MuxCase }
import chisel3.experimental.MultiIOModule


class InstructionDecode extends MultiIOModule {

  // Don't touch the test harness
  val testHarness = IO(
    new Bundle {
      val registerSetup = Input(new RegisterSetupSignals)
      val registerPeek  = Output(UInt(32.W))

      val testUpdates   = Output(new RegisterUpdates)
    })


  val io = IO(
    new Bundle {
      /**
        * TODO: Your code here.
        */
      val instructionIn  = Input(new Instruction)
      val PCIn           = Input(UInt(32.W))
      val writeEnable    = Input(Bool())
      val writeAddress   = Input(UInt(5.W))
      val writeData      = Input(UInt(32.W))

      val PCOut          = Output(UInt(32.W))
      val instructionOut = Output(new Instruction)
      val readData1      = Output(UInt(32.W))
      val readData2      = Output(UInt(32.W))
      val ALUOp          = Output(UInt(4.W))
      val controlSignals = Output(new ControlSignals)
    }
  )


  val registers = Module(new Registers)
  val decoder   = Module(new Decoder).io


  /**
    * Setup. You should not change this code
    */
  registers.testHarness.setup := testHarness.registerSetup
  testHarness.registerPeek    := registers.io.readData1
  testHarness.testUpdates     := registers.testHarness.testUpdates


  /**
    * TODO: Your code here.
    */
  registers.io.readAddress1 := io.instructionIn.registerRs1
  registers.io.readAddress2 := io.instructionIn.registerRs2
  registers.io.writeEnable  := io.writeEnable
  registers.io.writeAddress := io.writeAddress
  registers.io.writeData    := io.writeData

  decoder.instruction := io.instructionIn

  io.PCOut          := io.PCIn
  io.instructionOut := io.instructionIn

  //io.readData1 := registers.io.readData1
  io.readData1      := io.instructionIn.immediateIType.asUInt
  io.readData2      := registers.io.readData1
  io.ALUOp          := decoder.ALUop
  io.controlSignals := decoder.controlSignals
}
