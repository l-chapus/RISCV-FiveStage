package FiveStage
import chisel3._
import chisel3.util._
import chisel3.util.{ BitPat, MuxCase, MuxLookup }


class ALU extends Module {

  val io = IO(new Bundle {
      val op1            = Input(UInt(32.W))
      val op2            = Input(UInt(32.W))
      val aluOp          = Input(UInt(4.W))

      val Result         = Output(UInt(32.W))
   })
  
  
  import lookup._
  /*
  val ALUopMap: Array[(BitPat, UInt)] = Array(
    ADD    -> (io.op1 + io.op2),
    ADDI   -> (io.op1 + io.op2),
    SUB    -> (io.op1 - io.op2),
    BEQ    -> (io.op1 === io.op2),
    BNE    -> (io.op1 =/= io.op2),
    BLT    -> (io.op1.asSInt < io.op2.asSInt),
    BGE    -> (io.op1.asSInt >= io.op2.asSInt),
    BLTU   -> (io.op1 < io.op2),
    BGEU   -> (io.op1 >= io.op2),
  )


  io.Result := MuxCase(io.aluOp, ALUopMap.map { case (key, value) => (io.aluOp === key) -> value })

  // MuxLookup API: https://github.com/freechipsproject/chisel3/wiki/Muxes-and-Input-Selection#muxlookup
  // io.Result := MuxLookup(io.aluOp, 0.U(32.W), ALUopMap)
  


  // Tableau associatif (Map) des opérations supportées par l'ALU
  val aluOps = Map(
    ADDI -> ((a: UInt, b: UInt) => a + b),
    SUB  -> ((a: UInt, b: UInt) => a - b)
  )

  // Fonction de décodage de l'opcode et exécution de l'opération correspondante
  val decodedOp = Wire(UInt(32.W))
  decodedOp := 0.U // Valeur par défaut

  for ((aluOp, operation) <- aluOps) {
    when(io.aluOp === aluOp) {
      decodedOp := operation(io.op1, io.op2)
    }
  }
  
  io.Result := decodedOp
  */
  val op1convert = io.op1.asSInt
  val op2convert = io.op2.asSInt
  val result = Wire(SInt(12.W))

  result := op1convert + op2convert

  val output32Bit = Cat(Fill(20, result(11)), result).asUInt()
  
  io.Result := output32Bit
  //io.Result := result.asUInt
  //io.Result := io.op1 + io.op2

}
